﻿namespace DIGESA.Models.CannabisModels;

public class TopEspecialidadViewModel
{
    public string Especialidad { get; set; }
    public int Cantidad { get; set; }
}