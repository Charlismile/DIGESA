﻿namespace DIGESA.Models.CannabisModels;

public class ListSustModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Code { get; set; }
    public bool Active { get; set; } = true;
}