﻿namespace DIGESA.Models.CannabisModels;

public class RegistroMensualMedicoViewModel
{
    public int Ano { get; set; }
    public int Mes { get; set; }
    public int Cantidad { get; set; }

}