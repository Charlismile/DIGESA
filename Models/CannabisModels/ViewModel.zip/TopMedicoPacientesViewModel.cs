﻿namespace DIGESA.Models.CannabisModels;

public class TopMedicoPacientesViewModel
{
    public int MedicoId { get; set; }
    public string NombreMedico { get; set; }
    public int CantidadPacientes { get; set; }
}