﻿namespace DIGESA.Models.CannabisModels;

public class EstadisticaProvinciaViewModel
{
    public string Provincia { get; set; }
    public int Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}