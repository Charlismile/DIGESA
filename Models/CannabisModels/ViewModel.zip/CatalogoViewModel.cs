﻿namespace DIGESA.Models.CannabisModels;

public class CatalogoViewModel
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public bool IsActivo { get; set; }
}