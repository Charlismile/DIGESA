﻿namespace DIGESA.Models.CannabisModels;

public class RenovacionMesViewModel
{
    public string Mes { get; set; }
    public int Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}