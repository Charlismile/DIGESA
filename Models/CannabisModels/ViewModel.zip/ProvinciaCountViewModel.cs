﻿namespace DIGESA.Models.CannabisModels;

public class ProvinciaCountViewModel
{
    public string Provincia { get; set; }
    public int Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}