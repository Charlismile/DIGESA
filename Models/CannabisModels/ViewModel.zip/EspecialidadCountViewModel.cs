﻿namespace DIGESA.Models.CannabisModels;

public class EspecialidadCountViewModel
{
    public string Especialidad { get; set; }
    public int Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}