﻿namespace DIGESA.Models.CannabisModels;

public class RegistroMensualViewModel
{
    public string Mes { get; set; }
    public int Cantidad { get; set; }
}