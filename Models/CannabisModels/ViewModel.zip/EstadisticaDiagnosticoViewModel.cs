﻿namespace DIGESA.Models.CannabisModels;

public class EstadisticaDiagnosticoViewModel
{
    public string Diagnostico { get; set; }
    public int Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}