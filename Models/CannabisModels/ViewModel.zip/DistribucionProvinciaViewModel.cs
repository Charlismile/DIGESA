﻿namespace DIGESA.Models.CannabisModels;

public class DistribucionProvinciaViewModel
{
    public int ProvinciaId { get; set; }
    public int Cantidad { get; set; }
    public decimal Porcentaje { get; set; }
}